# Array de parches en HFSS

> Estado: en curso

Resumen en una frase: [qué diseñas, para qué banda y con qué objetivo].

![Diagrama de radiación del array](resultados/diagrama-array.png)

## Objetivo y especificaciones

| Parámetro | Objetivo | Resultado |
|---|---|---|
| Frecuencia central | [X GHz] | [X GHz] |
| Ancho de banda (S11 < −10 dB) | [X MHz] | [X MHz] |
| Ganancia | [X dBi] | [X dBi] |
| Nº de elementos y separación | [N, X λ] | [N, X λ] |
| Apuntamiento máximo sin lóbulos de rejilla | [±X°] | [±X°] |

## Diseño

- **Sustrato:** [material, εr, tg δ, espesor].
- **Elemento:** [dimensiones del parche y tipo de alimentación].
- **Red de alimentación:** [descripción].
- **Condiciones de simulación en HFSS:** [tipo de solución, frecuencia de adaptación, caja de radiación, mallado].

## Resultados

1. **Elemento aislado:** S11 y diagrama de radiación.
2. **Array:** S11 de cada puerto, acoplamiento mutuo y diagrama para varios ángulos de apuntamiento.
3. **Comparación:** elemento aislado frente a array.

Escribe aquí qué cumple y qué no, y por qué.

## Cómo reproducirlo

1. Abre `hfss/array_parches.aedt` en Ansys Electronics Desktop [versión].
2. Lanza el análisis `[nombre]` y el barrido `[nombre]`.
3. Los datos exportados están en `resultados/` en formato `.csv`.

## Estructura del repositorio

- `hfss/`: proyecto de HFSS (o capturas y descripción si el archivo es demasiado grande).
- `resultados/`: imágenes y datos exportados.
- `scripts/`: scripts de postprocesado y automatización.
- `docs/`: notas y referencias.

## Lecciones aprendidas

- [Lo que no funcionó a la primera y cómo lo resolviste.]

## Próximos pasos

- Repetir el diseño con un script de Python (PyAEDT).
- [Fabricación y medida, si las haces.]
